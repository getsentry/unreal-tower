#import <Foundation/Foundation.h>
NS_ASSUME_NONNULL_BEGIN

/// Options for experimental features that are subject to change or may be removed in future
/// versions.
@interface SentryObjCExperimentalOptions : NSObject

#if !SDK_V10
/**
 * Captures C++ exception stack traces at the throw site by hooking @c __cxa_throw.
 * Hooking @c __cxa_throw has unresolved safety and symbolication concerns. When @c NO, unhandled
 * C++ exceptions are still captured through @c std::terminate when crash handling is enabled, but
 * stacks may not identify the throw site.
 * @warning Disabled by default. Use and monitor this experimental implementation with care.
 * @see https://github.com/getsentry/sentry-cocoa/issues/5309
 */
@property (nonatomic) BOOL enableUnhandledCPPExceptionsV2;
#endif // !SDK_V10

/**
 * Enables swizzling for automatic network instrumentation of the new URLSession HTTP loader.
 * Requires @c enableSwizzling and an enabled network tracking feature.
 * Classic-loader instrumentation is unaffected by this option.
 *
 * @warning This is an experimental feature and is disabled by default.
 * @note Configure this option before starting the SDK. Installed swizzles remain for the process
 * lifetime, but bypass new-loader instrumentation if the SDK restarts with this option disabled.
 */
@property (nonatomic) BOOL enableNewURLLoaderSwizzling;

#if !SDK_V10
/**
 * When enabled, the SDK uses a more efficient mechanism for detecting watchdog terminations.
 * @deprecated This option will be removed in v10, where the improved watchdog termination tracking
 * mechanism is enabled by default.
 */
@property (nonatomic) BOOL enableWatchdogTerminationsV2
    __attribute__((deprecated("enableWatchdogTerminationsV2 is deprecated and will be removed in "
                              "v10, where the improved watchdog termination tracking mechanism is "
                              "enabled by default.")));
#endif

/**
 * Reduces SDK start overhead by swizzling each @c UIViewController subclass lazily, the first time
 * an instance of it is created, instead of eagerly discovering and swizzling every subclass when
 * the SDK starts.
 *
 * By default, the SDK scans loaded binary images for all @c UIViewController subclasses at start
 * and swizzles them up front. This realizes every subclass to inspect it, so the cost grows with
 * the number of view controllers in the app - including ones it never uses - and it realizes
 * @c \@available -gated subclasses that reference newer-framework types, which crashes on OS
 * versions below the gate.
 *
 * With this option, only classes the app actually instantiates are touched: a class that can't
 * exist on the current OS is never instantiated, so it's never realized or swizzled. This cuts
 * start-up work and avoids the gated-subclass crash while producing the same @c ui.load
 * auto-instrumentation transactions.
 *
 * @warning This is an experimental feature and is therefore disabled by default.
 * @see https://github.com/getsentry/sentry-cocoa/issues/8548
 */
@property (nonatomic) BOOL enableUIViewControllerInitSwizzling;

/// Initializes experimental options with default values.
- (instancetype)init;

@end

NS_ASSUME_NONNULL_END
