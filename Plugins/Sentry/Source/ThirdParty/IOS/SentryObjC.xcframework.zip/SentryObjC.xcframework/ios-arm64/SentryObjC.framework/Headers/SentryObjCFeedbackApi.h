#import <Foundation/Foundation.h>
#if !__has_include(<SentryObjC/SentryObjCDefines.h>)
#    import "SentryObjCDefines.h"
#else
#    import <SentryObjC/SentryObjCDefines.h>
#endif

#if TARGET_OS_IOS && SENTRY_OBJC_HAS_UIKIT

@class UIImage;
@class SentryObjCUserFeedbackConfiguration;

NS_ASSUME_NONNULL_BEGIN

/// API for interacting with the User Feedback feature.
@interface SentryObjCFeedbackApi : NSObject
SENTRY_NO_INIT

/**
 * Show the feedback form using the best available presenter.
 * @note This method must be called from the main thread.
 * @warning This is an experimental feature and may still have bugs.
 */
- (void)show NS_EXTENSION_UNAVAILABLE("Not available in app extensions.");

/**
 * Show the feedback form using the best available presenter.
 * @param screenshot An optional screenshot to attach to the feedback form.
 * @note This method must be called from the main thread.
 * @warning This is an experimental feature and may still have bugs.
 */
- (void)showWithScreenshot:(nullable UIImage *)screenshot
    NS_EXTENSION_UNAVAILABLE("Not available in app extensions.");

/**
 * Show the feedback form using the best available presenter and form-specific configuration.
 * @param configure A block to customize this feedback form presentation.
 * @note Per-presentation configuration only affects the displayed form. Widget, custom button,
 * screenshot trigger, and shake gesture settings are global and ignored for individual
 * presentations.
 * @note This method must be called from the main thread.
 * @warning This is an experimental feature and may still have bugs.
 */
- (void)showWithConfigure:
    (nullable void (^)(SentryObjCUserFeedbackConfiguration *configuration))configure
    NS_EXTENSION_UNAVAILABLE("Not available in app extensions.");

/**
 * Show the feedback form using the best available presenter, screenshot attachment, and
 * form-specific configuration.
 * @param screenshot An optional screenshot to attach to the feedback form.
 * @param configure A block to customize this feedback form presentation.
 * @note Per-presentation configuration only affects the displayed form. Widget, custom button,
 * screenshot trigger, and shake gesture settings are global and ignored for individual
 * presentations.
 * @note This method must be called from the main thread.
 * @warning This is an experimental feature and may still have bugs.
 */
- (void)showWithScreenshot:(nullable UIImage *)screenshot
                 configure:(nullable void (^)(
                               SentryObjCUserFeedbackConfiguration *configuration))configure
    NS_EXTENSION_UNAVAILABLE("Not available in app extensions.");

/**
 * Enables the shake-gesture trigger for the feedback form at runtime.
 * @discussion Use this to enable shake-to-report after @c SentrySDK.start, e.g. once an
 * asynchronously fetched feature flag resolves. Requires the User Feedback integration to be
 * configured; otherwise this is a no-op.
 * @note This method must be called from the main thread.
 * @warning This is an experimental feature and may still have bugs.
 */
- (void)enableOnShake NS_EXTENSION_UNAVAILABLE("Not available in app extensions.");

/**
 * Disables the shake-gesture trigger for the feedback form at runtime.
 * @discussion Requires the User Feedback integration to be configured; otherwise this is a no-op.
 * @note This method must be called from the main thread.
 * @warning This is an experimental feature and may still have bugs.
 */
- (void)disableOnShake NS_EXTENSION_UNAVAILABLE("Not available in app extensions.");

#    if !SDK_V10
/**
 * Show the feedback widget button.
 * @warning This is an experimental feature and may still have bugs.
 * @deprecated The Sentry-managed User Feedback widget is deprecated and will be removed in v10.
 */
- (void)showWidget NS_EXTENSION_UNAVAILABLE("Not available in app extensions.")
    __attribute__((deprecated("The Sentry-managed User Feedback widget is deprecated and will be "
                              "removed in v10.")));

/**
 * Hide the feedback widget button.
 * @warning This is an experimental feature and may still have bugs.
 * @deprecated The Sentry-managed User Feedback widget is deprecated and will be removed in v10.
 */
- (void)hideWidget NS_EXTENSION_UNAVAILABLE("Not available in app extensions.")
    __attribute__((deprecated("The Sentry-managed User Feedback widget is deprecated and will be "
                              "removed in v10.")));
#    endif

@end

NS_ASSUME_NONNULL_END

#endif
